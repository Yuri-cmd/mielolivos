<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css" />
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.7/css/jquery.dataTables.min.css" />
    <link rel="stylesheet" href="https://cdn.datatables.net/responsive/2.5.0/css/responsive.dataTables.min.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
</head>
<style>
    tbody tr {
        text-align: center;
    }

    .card {
        width: 80%;
    }

    .card-body {
        height: 200px;
        display: flex;
        justify-content: center;
        align-items: center;
    }

    .swiper {
        width: 100%;
        height: 300px;
    }

    .swiper-slide {
        display: flex;
        justify-content: center;
        align-items: center;
    }

    .formulario th {
        background-color: #B8CCE4;
    }

    .formulario th,
    .formulario td {
        border: 1px solid black;
        font-size: 12px;
        text-align: center;
    }

    .boton {
        display: flex;
        justify-content: center;
        align-items: center;
        padding: 10px 20px;
        font-size: 16px;
        font-weight: bold;
        text-align: center;
        text-decoration: none;
        border: 2px solid #3498db;
        /* Cambia el color del borde seg n tus preferencias */
        color: #3498db;
        /* Cambia el color del texto seg n tus preferencias */
        border-radius: 5px;
        transition: background-color 0.3s ease;
    }

    .boton:hover {
        background-color: #3498db;
        /* Cambia el color de fondo al pasar el mouse seg n tus preferencias */
        color: #fff;
        /* Cambia el color del texto al pasar el mouse seg n tus preferencias */
    }

    .botond {
        display: flex;
        justify-content: center;
        align-items: center;
        padding: 10px 20px;
        font-size: 16px;
        font-weight: bold;
        text-align: center;
        text-decoration: none;
        border: 2px solid #58D68D;
        /* Cambia el color del borde seg n tus preferencias */
        color: #58D68D;
        /* Cambia el color del texto seg n tus preferencias */
        border-radius: 5px;
        transition: background-color 0.3s ease;
    }

    .botond:hover {
        background-color: #28B463;
        /* Cambia el color de fondo al pasar el mouse seg n tus preferencias */
        color: #fff;
        /* Cambia el color del texto al pasar el mouse seg n tus preferencias */
    }

    .boton svg {
        margin-right: 5px;
        /* A ade un peque o espacio entre el icono y el texto */
    }

    .contenedor {
        width: 100%;
        height: 90vh;
        margin-top: 56px;
        padding: 10px;
        display: flex;
    }

    .container-cards div {
        margin-bottom: 10px;
    }

    .cardm {
        width: fit-content;
        height: auto;
        display: flex;
        flex-direction: column;
        align-items: center;
        padding: 3px;
        box-shadow: rgba(99, 99, 99, 0.2) 0px 2px 8px 0px;
    }

    .cardscroll {
        cursor: move;
    }

    .cardH {
        width: 100%;
        height: auto;
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 10px;
        box-shadow: rgba(99, 99, 99, 0.2) 0px 2px 8px 0px;
    }

    .contenedor-row {
        display: flex;
        flex-direction: column;
        align-items: center;
    }

    .contenedor-row div {
        margin-bottom: 10px;
    }

    .eliminar {
        display: inline-block;
        margin-left: 5px;
        color: red;
        font-weight: bold;
        text-decoration: none;
    }

    .eliminar:hover {
        text-decoration: underline;
    }

    input[type="number"]::-webkit-inner-spin-button,
    input[type="number"]::-webkit-outer-spin-button {
        -webkit-appearance: none;
        margin: 0;
    }

    input[type="number"] {
        -moz-appearance: textfield;
    }

    .cardm input {
        width: 80px;
    }
</style>

<body>
    <nav class="navbar navbar-dark bg-dark fixed-top">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">Coorporacion marsam</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas"
                data-bs-target="#offcanvasDarkNavbar" aria-controls="offcanvasDarkNavbar"
                aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="offcanvas offcanvas-end text-bg-dark" tabindex="-1" id="offcanvasDarkNavbar"
                aria-labelledby="offcanvasDarkNavbarLabel">
                <div class="offcanvas-header">
                    <h5 class="offcanvas-title" id="offcanvasDarkNavbarLabel">Menú</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="offcanvas"
                        aria-label="Close"></button>
                </div>
                <div class="offcanvas-body">
                    <ul class="navbar-nav justify-content-end flex-grow-1 pe-3">
                        <li class="nav-item">
                            <a class="nav-link active" aria-current="page" href="#">Bienvenido
                                <?php echo e(Session::get('usuario')); ?></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link active" aria-current="page" href="../controller/logout.php">Cerar
                                Sesión</a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </nav>
    <main>
        <?php echo $__env->yieldContent('content'); ?>
    </main>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.7/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/responsive/2.5.0/js/dataTables.responsive.min.js"></script>

    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.min.js"></script>
    <script src="<?php echo e(asset('js/admin.js')); ?>"></script>
</body>

</html>
<?php /**PATH C:\laragon\www\mielolivos\resources\views/layout.blade.php ENDPATH**/ ?>