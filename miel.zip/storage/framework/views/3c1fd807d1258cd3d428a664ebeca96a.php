<!DOCTYPE html>
<html lang="en">

<head>
    <title>LOTES CONSERGEN BRAMILEX</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!--===============================================================================================-->
    <link rel="icon" type="image/png" href="<?php echo e(asset('img/icons/favicon.ico')); ?>" />
    <!--===============================================================================================-->
    
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('fonts/font-awesome-4.7.0/css/font-awesome.min.css')); ?>">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('fonts/Linearicons-Free-v1.0.0/icon-font.min.css')); ?>">
    <!--===============================================================================================-->
    
    <!--===============================================================================================-->
    
    <!--===============================================================================================-->
    
    <!--===============================================================================================-->
    
    <!--===============================================================================================-->
    
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/util.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/main.css')); ?>">
    <!--===============================================================================================-->
</head>

<body style="background-color: #666666;">
    <div class="limiter">
        <div class="container-login100">
            <div class="wrap-login100">
                <form method="POST" action="<?php echo e(route('login')); ?>" class="login100-form">
                    <?php echo csrf_field(); ?>
                    <div style="display: flex; justify-content: center; align-items: center; margin-bottom: 10px;">
                        <!-- <img src="./assets/img/logo.jpg" alt="" style="width: 250px;"> -->
                    </div>
                    <span class="login100-form-title p-b-43">
                        Inicio de sesi&oacute;n
                    </span>
                    <div class="wrap-input100">
                        <input class="input100" type="text" id="usuario" name="usuario" required>
                        <span class="focus-input100"></span>
                        <label class="label-input100" for="username">Usuario</label>
                    </div>
                    <div class="wrap-input100">
                        <input class="input100" type="password" id="password" name="password" required>
                        <span class="focus-input100"></span>
                        <label class="label-input100" for="password">Contraseña</label>
                    </div>
                    <div class="container-login100-form-btn">
                        <button type="submit" class="login100-form-btn">Login</button>
                    </div>

                </form>
                <div class="login100-more" style="background-image: url('<?php echo e(asset('img/login.jpg')); ?>');">
                </div>
            </div>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        <?php if($errors->has('usuario')): ?>
            Swal.fire({
                icon: "error",
                title: "Credenciales Incorrectas",
                text: "Usuario o contraseña incorrectas.",
            });
        <?php endif; ?>
    </script>
</body>

</html>
<?php /**PATH C:\laragon\www\mielolivos\resources\views/auth/login.blade.php ENDPATH**/ ?>